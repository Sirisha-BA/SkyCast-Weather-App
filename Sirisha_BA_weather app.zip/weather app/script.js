// =============================================
//  SkyCast Weather App — script.js
// =============================================

// ⚠️ Replace with your API key from openweathermap.org
const API_KEY = "09ea195deddf1920daf6e76c1bd521e2";
const BASE_URL = "https://api.openweathermap.org/data/2.5";
const FORECAST_URL = "https://api.openweathermap.org/data/2.5/forecast";

const cityInput   = document.getElementById("cityInput");
const weatherCard = document.getElementById("weatherCard");
const errorBanner = document.getElementById("errorBanner");
const errorMsg    = document.getElementById("errorMsg");
const loader      = document.getElementById("loader");

cityInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") fetchWeather();
});

async function fetchWeather() {
  const city = cityInput.value.trim();
  if (!city) { showError("Please enter a city name."); return; }

  hideError(); hideCard(); showLoader();

  try {
    const weatherRes = await fetch(
      `${BASE_URL}/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`
    );

    if (!weatherRes.ok) {
      if (weatherRes.status === 404)
        showError(`City "${city}" not found. Please check the spelling.`);
      else if (weatherRes.status === 401)
        showError("Invalid API key. Please add your key in script.js.");
      else
        showError("Something went wrong. Please try again.");
      hideLoader(); return;
    }

    const weatherData = await weatherRes.json();
    const forecastRes = await fetch(
      `${FORECAST_URL}?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`
    );
    const forecastData = forecastRes.ok ? await forecastRes.json() : null;

    hideLoader();
    renderWeather(weatherData);
    if (forecastData) renderForecast(forecastData);

  } catch (err) {
    hideLoader();
    showError("Network error. Please check your connection.");
    console.error(err);
  }
}

function renderWeather(data) {
  const {
    name,
    sys: { country, sunrise, sunset },
    main: { temp, feels_like, humidity, pressure },
    weather: [{ description, icon }],
    wind: { speed },
    visibility,
    timezone
  } = data;

  document.getElementById("cityName").textContent    = name;
  document.getElementById("countryTag").textContent  = country;

  const localTime = new Date(
    (Date.now() / 1000 + timezone + new Date().getTimezoneOffset() * 60) * 1000
  );
  document.getElementById("dateTime").textContent    = formatDateTime(localTime);
  document.getElementById("tempValue").textContent   = Math.round(temp);
  document.getElementById("feelsLike").textContent   = `Feels like ${Math.round(feels_like)}°C`;
  document.getElementById("conditionLabel").textContent = capitalise(description);
  document.getElementById("weatherIcon").src         = `https://openweathermap.org/img/wn/${icon}@2x.png`;
  document.getElementById("humidity").textContent    = `${humidity}%`;
  document.getElementById("windSpeed").textContent   = `${Math.round(speed * 3.6)} km/h`;
  document.getElementById("visibility").textContent  = `${(visibility / 1000).toFixed(1)} km`;
  document.getElementById("pressure").textContent    = `${pressure} hPa`;
  document.getElementById("sunrise").textContent     = formatTime(
    new Date((sunrise + timezone + new Date().getTimezoneOffset() * 60) * 1000)
  );
  document.getElementById("sunset").textContent      = formatTime(
    new Date((sunset + timezone + new Date().getTimezoneOffset() * 60) * 1000)
  );

  applyWeatherTheme(icon);
  showCard();
}

function renderForecast(data) {
  const strip = document.getElementById("forecastStrip");
  strip.innerHTML = "";

  const daily = {};
  data.list.forEach(item => {
    const dayKey = new Date(item.dt * 1000).toDateString();
    if (!daily[dayKey]) daily[dayKey] = { highs: [], lows: [], icon: item.weather[0].icon };
    daily[dayKey].highs.push(item.main.temp_max);
    daily[dayKey].lows.push(item.main.temp_min);
    daily[dayKey].icon = item.weather[0].icon;
  });

  Object.entries(daily).slice(0, 5).forEach(([dayStr, { highs, lows, icon }]) => {
    const date    = new Date(dayStr);
    const dayName = date.toLocaleDateString("en-US", { weekday: "short" });
    const high    = Math.round(Math.max(...highs));
    const low     = Math.round(Math.min(...lows));

    const el = document.createElement("div");
    el.className = "forecast-day";
    el.innerHTML = `
      <p class="forecast-day-name">${dayName}</p>
      <img src="https://openweathermap.org/img/wn/${icon}.png" alt="weather" />
      <span class="forecast-temp-high">${high}°</span>
      <span class="forecast-temp-low">${low}°</span>
    `;
    strip.appendChild(el);
  });
}

function applyWeatherTheme(iconCode) {
  const root = document.documentElement;
  if (iconCode.startsWith("01")) {
    root.style.setProperty("--accent", iconCode.endsWith("n") ? "#a8dadc" : "#f9c74f");
    root.style.setProperty("--glow",   iconCode.endsWith("n") ? "rgba(168,218,220,0.12)" : "rgba(249,199,79,0.15)");
  } else if (["09","10","11"].some(c => iconCode.startsWith(c))) {
    root.style.setProperty("--accent", "#74b3ff");
    root.style.setProperty("--glow",   "rgba(116,179,255,0.15)");
  } else if (iconCode.startsWith("13")) {
    root.style.setProperty("--accent", "#caf0f8");
    root.style.setProperty("--glow",   "rgba(202,240,248,0.12)");
  } else {
    root.style.setProperty("--accent", "#3af0c8");
    root.style.setProperty("--glow",   "rgba(58,240,200,0.15)");
  }
}

function showCard()   { weatherCard.classList.add("show"); }
function hideCard()   { weatherCard.classList.remove("show"); }
function showLoader() { loader.classList.add("show"); }
function hideLoader() { loader.classList.remove("show"); }
function showError(msg) { errorMsg.textContent = msg; errorBanner.classList.add("show"); }
function hideError()    { errorBanner.classList.remove("show"); }

function formatDateTime(date) {
  return date.toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric",
    hour: "2-digit", minute: "2-digit", hour12: true
  });
}

function formatTime(date) {
  return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
}

function capitalise(str) {
  return str.replace(/\b\w/g, c => c.toUpperCase());
}